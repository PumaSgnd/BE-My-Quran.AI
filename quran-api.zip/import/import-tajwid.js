// import/import-tajwid.js
require('dotenv').config();
const fs = require('fs/promises');
const path = require('path');

// Pakai koneksi project kamu (di controller kamu import dari ../config/db)
// karena file ini ada di folder `import/`, path ke src/config/db adalah ../src/config/db
const db = require('../src/config/db');

function normVerseKey(vk) {
    // Normalisasi "2:001" -> "2:1", "2:010" -> "2:10"
    const m = String(vk || '').match(/^(\d+):0*([1-9]\d*)$/);
    if (m) return `${m[1]}:${m[2]}`;
    return String(vk || '');
}

async function main() {
    const jsonPathArg = process.argv[2] || path.join(process.cwd(), 'data', 'qpc-hafs-tajweed.json');
    const jsonPath = path.resolve(jsonPathArg);

    console.log('>>');
    console.log(`[dotenv] loaded. Reading: ${jsonPath}`);

    const raw = await fs.readFile(jsonPath, 'utf8');
    let rawJson;
    try {
        rawJson = JSON.parse(raw);
    } catch (e) {
        console.error('JSON parse error:', e.message);
        process.exit(1);
    }

    // QUL dataset: root adalah OBJECT { "1:1": {...}, "1:2": {...}, ... }
    // tapi biar fleksibel, kalau array juga tetap didukung.
    let rows = [];
    if (Array.isArray(rawJson)) {
        for (const it of rawJson) {
            const verse_key = normVerseKey(it.verse_key || `${it.surah}:${it.ayah}`);
            if (!verse_key) continue;
            const [s, a] = verse_key.split(':').map(n => parseInt(n, 10));
            rows.push({
                verse_key,
                surah_number: s,
                ayah_number: a,
                markup: String(it.text || '').trim()
            });
        }
    } else if (rawJson && typeof rawJson === 'object') {
        for (const [key, it] of Object.entries(rawJson)) {
            const verse_key = normVerseKey(it.verse_key || key);
            if (!verse_key) continue;
            const [s, a] = verse_key.split(':').map(n => parseInt(n, 10));
            rows.push({
                verse_key,
                surah_number: s,
                ayah_number: a,
                markup: String(it.text || '').trim()
            });
        }
    }

    console.log(`Parsed ${rows.length} tajwid rows from ${jsonPath}`);
    if (!rows.length) {
        console.error('No data parsed. Check your JSON format.');
        process.exit(1);
    }

    // Ambil ayah_id dari ayahs berdasarkan verse_key
    const verseKeys = rows.map(r => r.verse_key);
    const ayahRes = await db.query(
        `SELECT id, verse_key FROM ayahs WHERE verse_key = ANY($1)`,
        [verseKeys]
    );
    const vkToAyahId = new Map(ayahRes.rows.map(r => [r.verse_key, r.id]));

    let missing = 0;
    for (const r of rows) {
        if (!vkToAyahId.has(r.verse_key)) missing++;
    }
    if (missing) {
        console.warn(`⚠️  ${missing} verse_key dari tajwid tidak ditemukan di tabel ayahs (akan dilewati).`);
    }

    // Pastikan ada unique index di (ayah_id) agar ON CONFLICT bisa jalan
    await db.query(`CREATE UNIQUE INDEX IF NOT EXISTS tajwid_verses_ayah_id_uniq ON tajwid_verses(ayah_id)`);

    // Insert (upsert) dalam transaksi
    await db.query('BEGIN');
    try {
        let inserted = 0, updated = 0, skipped = 0;

        for (const r of rows) {
            const ayah_id = vkToAyahId.get(r.verse_key);
            if (!ayah_id) { skipped++; continue; }

            // NOTE: kolom yang tersedia: id, ayah_id, verse_key, surah_number, ayah_number, markup, created_at, updated_at
            const q = `
        INSERT INTO tajwid_verses (ayah_id, verse_key, surah_number, ayah_number, markup, created_at, updated_at)
        VALUES ($1, $2, $3, $4, $5, NOW(), NOW())
        ON CONFLICT (ayah_id) DO UPDATE
          SET verse_key = EXCLUDED.verse_key,
              surah_number = EXCLUDED.surah_number,
              ayah_number  = EXCLUDED.ayah_number,
              markup       = EXCLUDED.markup,
              updated_at   = NOW()
        RETURNING (xmax = 0) AS inserted -- trick: true jika insert baru, false jika update
      `;
            const { rows: ret } = await db.query(q, [
                ayah_id,
                r.verse_key,
                r.surah_number,
                r.ayah_number,
                r.markup
            ]);
            if (ret[0]?.inserted) inserted++;
            else updated++;
        }

        await db.query('COMMIT');
        console.log(`✅ Done. Inserted: ${inserted}, Updated: ${updated}, Skipped: ${skipped}`);
    } catch (e) {
        await db.query('ROLLBACK');
        console.error('❌ Import failed, transaction rolled back:', e.message);
        process.exit(1);
    }
    process.exit(0);
}

main().catch(err => {
    console.error('Fatal:', err);
    process.exit(1);
});
