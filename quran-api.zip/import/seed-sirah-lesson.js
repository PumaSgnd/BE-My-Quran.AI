// import/seed-sirah-lesson.js

const { Pool } = require('pg');
const path = require('path');
require('dotenv').config({ path: path.resolve(__dirname, '../.env') });

const pool = new Pool({
    user: process.env.DB_USER,
    host: process.env.DB_HOST,
    database: process.env.DB_DATABASE,
    password: process.env.DB_PASSWORD,
    port: process.env.DB_PORT,
});

const seedSirahLesson = async () => {
    const client = await pool.connect();
    try {
        console.log('Memulai proses seeding pelajaran detail Topik Seri Nabi Muhammad...');
        await client.query('BEGIN');

        // 1. Cari ID dari materi induk "Seri Nabi Muhammad"
        const materialRes = await client.query("SELECT id FROM learning_materials WHERE action_value = 'sirah-nabawiyah'");
        if (materialRes.rows.length === 0) {
            throw new Error("Materi 'Seri Nabi Muhammad' (action_value: 'sirah-nabawiyah') tidak ditemukan. Jalankan seed-all-learning-content.js dulu.");
        }
        const materialId = materialRes.rows[0].id;
        console.log(`- Materi Induk "Seri Nabi Muhammad" ditemukan dengan ID: ${materialId}`);

        // 2. Definisikan semua pelajaran di dalam Topik ini
        const sirahLessons = [
            { title: "Al-Ahzaab", subtitle: "Prophet Muhammad as the Final Messenger of Allah", contentValue: "sirah-ahzaab-1", order: 1 },
            { title: "Al-Baqara", subtitle: "Mercy to the Worlds", contentValue: "sirah-baqara-1", order: 2 },
            { title: "Al-Qalam", subtitle: "His Exemplary Character", contentValue: "sirah-qalam-1", order: 3 },
            // Tambahkan pelajaran lain dari desain di sini jika perlu
        ];

        const lessonIds = {}; // Untuk menyimpan ID pelajaran yang baru dibuat

        // 3. Masukkan semua pelajaran di atas ke tabel `lessons`
        for (const lesson of sirahLessons) {
            const res = await client.query(
                "INSERT INTO lessons (material_id, title, subtitle, content_type, content_value, display_order) VALUES ($1, $2, $3, 'lesson', $4, $5) RETURNING id",
                [materialId, lesson.title, lesson.subtitle, lesson.contentValue, lesson.order]
            );
            lessonIds[lesson.contentValue] = res.rows[0].id;
        }
        console.log(`- Berhasil menanamkan ${sirahLessons.length} pelajaran untuk Topik Seri Nabi Muhammad.`);

        // 4. Definisikan semua "slide" untuk pelajaran pertama ("sirah-ahzaab-1")
        const firstLessonId = lessonIds['sirah-ahzaab-1'];
        const steps = [
            { order: 1, type: 'verse_display', content: { verse_key: "33:40", show_play_button: true, transliteration: "mā kāna muḥammadun abā aḥadim mir rijālikum wa lākir rasụlallāhi wa khātaman-nabiyyīn, wa kānallāhu bikulli syai`in 'alīmā" } },
            { order: 2, type: 'translation_display', content: { verse_key: "33:40" } },
            { order: 3, type: 'information_text', content: { title: "Informasi", text: "Nabi Muhammad ﷺ adalah Utusan Allah yang terakhir. Ayat tersebut menjelaskan dengan jelas bahwa beliau bukanlah sang ayah biologis dari seorang anak laki-laki, melainkan \"Penutup para Nabi\" yang menandakan akhir dari garis keturunan para nabi." } },
            { order: 4, type: 'hadith_reference', content: { title: "Hadith", text: "Nabi pernah bersabda: \"Aku ditulis di sisi Allah sebagai penutup para nabi, sementara Adam (saw) masih dibentuk dari tanah liat.\" Hadits yang diriwayatkan oleh Imam Ahmad" } },
            { order: 5, type: 'information_text', content: { title: "Informasi", text: "Sebagai utusan terakhir Allah, kehidupan dan karakternya menjadi panduan yang lengkap bagi umat Islam. Oleh karena itu, kita harus berusaha untuk mewujudkan ajaran kenabiannya, seperti bersikap baik, jujur, dan memperlakukan orang lain dengan penuh kasih sayang." } },
            { order: 6, type: 'knowledge_review_mcq', content: { title: "Knowledge Review", question: "Apa arti gelar “Penutup Para Nabi” yang ditujukan kepada Nabi Muhammad ﷺ?", options: ["Dia adalah seorang nab dikhususkan hanya untuk orang-orang Mekkah.", "Dia adalah nabi pertama yang diutus Allah.", "Dialah nabi terakhir, yang mengakhiri garis kenabian."], correct_index: 2 } },
            { order: 7, type: 'knowledge_review_mcq', content: { title: "Knowledge Review", question: "Pelajaran penting apa yang dapat diambil dari kehidupan Nabi Muhammad ﷺ yang dapat membantu umat Islam mengatasi tantangan mental dan fisik?", options: ["Menekankan kesabaran, ketergantungan kepada Allah, dan menjaga harapan", "Ketergantungan penuh pada kekayaan materi untuk mencari solusi.", "Ketergantungan penuh pada kekayaan materi untuk mencari solusi."], correct_index: 0 } },
            { order: 8, type: 'conclusion_text', content: { title: "Sebagai penutup", text: "Sebagai penutup, Nabi Muhammad ﷺ, sebagai Utusan Allah terakhir, berperan sebagai pemandu yang lengkap bagi umat manusia melalui kehidupan dan ajarannya. Perannya sebagai \"Penutup Para Nabi\" menegaskan penutup kenabiannya, dan kebijaksanaannya yang abadi menawarkan kepada kita elemen praktis dan spiritual untuk menavigasi tantangan hidup." } }
        ];

        // 5. Masukkan semua "slide" ke database
        for (const step of steps) {
            await client.query(
                'INSERT INTO lesson_steps (lesson_id, step_order, step_type, content) VALUES ($1, $2, $3, $4)',
                [firstLessonId, step.order, step.type, JSON.stringify(step.content)]
            );
        }
        console.log(`- Berhasil menanamkan ${steps.length} slide untuk pelajaran pertama Topik Seri Nabi Muhammad.`);

        await client.query('COMMIT');
        console.log('\n✅ Proses seeding semua konten pelajaran Seri Nabi Muhammad selesai dengan sukses!');
    } catch (error) {
        await client.query('ROLLBACK');
        console.error('❌ ERROR saat proses seeding:', error);
    } finally {
        client.release();
        await pool.end();
    }
};

seedSirahLesson();
