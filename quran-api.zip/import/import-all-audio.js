// import/import-all-audio.js

const fs = require('fs');
const path = require('path');
const { Pool } = require('pg');
require('dotenv').config({ path: path.resolve(__dirname, '../.env') });

const pool = new Pool({
    user: process.env.DB_USER,
    host: process.env.DB_HOST,
    database: process.env.DB_DATABASE,
    password: process.env.DB_PASSWORD,
    port: process.env.DB_PORT,
});

const recitersToImport = [
    {
        name: 'Abdur-Rahman as-Sudais',
        style: 'Murattal',
        slug: 'abdurrahman-as-sudais',
        folderName: 'Abdur-Rahman as-Sudais'
    },
    // Tambahkan objek baru di bawah ini
    {
        name: 'Mishari Rashid al-`Afasy',
        style: 'Murattal',
        slug: 'mishary-rashid-alafasy',
        folderName: 'Mishari Rashid al-`Afasy' // <-- Pastikan nama ini sama dengan nama folder
    }
    // Nanti bisa tambah Mishary di sini
];

const importAllAudioData = async () => {
    const client = await pool.connect();
    try {
        console.log('Memulai proses impor semua data audio...');
        await client.query('BEGIN');

        // Hapus data lama untuk memulai dari bersih
        await client.query('TRUNCATE TABLE reciters, audio_files, audio_segments RESTART IDENTITY CASCADE;');
        console.log('- Semua tabel audio lama berhasil dikosongkan.');

        for (const reciter of recitersToImport) {
            console.log(`\n--- Memproses Qari: ${reciter.name} ---`);

            const reciterInsertQuery = `
                INSERT INTO reciters (name, style, slug) VALUES ($1, $2, $3)
                ON CONFLICT (slug) DO UPDATE SET name = EXCLUDED.name, style = EXCLUDED.style
                RETURNING id;
            `;
            const reciterRes = await client.query(reciterInsertQuery, [reciter.name, reciter.style, reciter.slug]);
            const reciterId = reciterRes.rows[0].id;
            console.log(`- ID Qari: ${reciterId}`);

            // Impor Audio per Surah
            const surahAudioPath = path.join(__dirname, `../data/${reciter.folderName}/surah.json`);
            if (fs.existsSync(surahAudioPath)) {
                const audioData = JSON.parse(fs.readFileSync(surahAudioPath, 'utf8'));
                const audioFiles = Object.values(audioData);
                for (const audioFile of audioFiles) {
                    if (audioFile && audioFile.surah_number && audioFile.audio_url) {
                        await client.query(
                            'INSERT INTO audio_files (surah_id, reciter_id, audio_url) VALUES ($1, $2, $3)',
                            [audioFile.surah_number, reciterId, audioFile.audio_url]
                        );
                    }
                }
                console.log(`- Berhasil memproses ${audioFiles.length} file audio per surah.`);
            } else {
                console.warn(`- Peringatan: file surah.json tidak ditemukan untuk ${reciter.name}.`);
            }

            // Impor Segmen Audio per Kata
            const segmentsPath = path.join(__dirname, `../data/${reciter.folderName}/segments.json`);
            if (fs.existsSync(segmentsPath)) {
                const segmentsData = JSON.parse(fs.readFileSync(segmentsPath, 'utf8'));
                const verseKeys = Object.keys(segmentsData);
                for (let i = 0; i < verseKeys.length; i++) {
                    const verseKey = verseKeys[i];
                    const ayahSegments = segmentsData[verseKey].segments;
                    const ayahRes = await client.query('SELECT id FROM ayahs WHERE verse_key = $1', [verseKey]);
                    if (ayahRes.rows.length > 0) {
                        const ayahId = ayahRes.rows[0].id;
                        for (const segment of ayahSegments) {
                            const [pos, start, end] = segment;

                            // --- INI PERBAIKANNYA ---
                            // Cek apakah start dan end adalah angka yang valid sebelum dimasukkan
                            if (typeof start === 'number' && typeof end === 'number' && !isNaN(start) && !isNaN(end)) {
                                await client.query(
                                    'INSERT INTO audio_segments (ayah_id, reciter_id, word_position, start_time_ms, end_time_ms) VALUES ($1, $2, $3, $4, $5)',
                                    [ayahId, reciterId, pos, Math.round(start), Math.round(end)]
                                );
                            } else {
                                console.warn(`- Peringatan: Segmen tidak valid dilewati untuk verse_key ${verseKey}. Data: [${pos}, ${start}, ${end}]`);
                            }
                            // --------------------------
                        }
                    }
                    if ((i + 1) % 500 === 0) console.log(`  - Memproses segmen... ${i + 1}/${verseKeys.length} ayat`);
                }
                console.log(`- Berhasil mengimpor segmen untuk ${verseKeys.length} ayat.`);
            } else {
                console.warn(`- Peringatan: file segments.json tidak ditemukan untuk ${reciter.name}.`);
            }
        }

        await client.query('COMMIT');
        console.log('\n🎉 SEMUA DATA AUDIO BERHASIL DIIMPOR!');

    } catch (error) {
        await client.query('ROLLBACK');
        console.error('\n❌ TERJADI ERROR SAAT PROSES IMPOR:', error);
    } finally {
        client.release();
        await pool.end();
    }
};

importAllAudioData();
