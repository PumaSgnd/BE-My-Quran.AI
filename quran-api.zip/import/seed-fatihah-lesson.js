// import/seed-fatihah-lesson.js

const { Pool } = require('pg');
const path = require('path');
require('dotenv').config({ path: path.resolve(__dirname, '../.env') });

const pool = new Pool({
    user: process.env.DB_USER,
    host: process.env.DB_HOST,
    database: process.env.DB_DATABASE,
    password: process.env.DB_PASSWORD,
    port: process.env.DB_PORT,
});

const seedFatihahLesson = async () => {
    const client = await pool.connect();
    try {
        console.log('Memulai proses seeding pelajaran detail Al-Fatihah...');
        await client.query('BEGIN');

        // 1. Cari ID dari materi induk "Surah-surah Al-Quran"
        const materialRes = await client.query("SELECT id FROM learning_materials WHERE action_value = 'all'");
        if (materialRes.rows.length === 0) {
            throw new Error("Materi 'Quranic Surahs' (action_value: 'all') tidak ditemukan. Jalankan seed-learning.js dulu.");
        }
        const materialId = materialRes.rows[0].id;

        // 2. Buat entri pelajaran untuk "Surat Al-Fatihah" di tabel `lessons`
        const lessonQuery = `
            INSERT INTO lessons (material_id, title, subtitle, content_type, content_value, display_order)
            VALUES ($1, $2, $3, $4, $5, $6)
            ON CONFLICT DO NOTHING RETURNING id;
        `;
        // Kita gunakan display_order = 1 karena ini surah pertama
        const lessonRes = await client.query(lessonQuery, [materialId, 'Surat Al-Fatihah', '7 Ayat', 'lesson', 'surah-1', 1]);

        // Jika pelajaran sudah ada, ambil IDnya. Jika baru dibuat, ambil ID barunya.
        let lessonId;
        if (lessonRes.rows.length > 0) {
            lessonId = lessonRes.rows[0].id;
        } else {
            const existingLesson = await client.query("SELECT id FROM lessons WHERE content_value = 'surah-1'");
            lessonId = existingLesson.rows[0].id;
        }
        console.log(`- Pelajaran Al-Fatihah diproses dengan ID: ${lessonId}`);

        // 3. Hapus langkah-langkah lama untuk pelajaran ini agar tidak duplikat
        await client.query('DELETE FROM lesson_steps WHERE lesson_id = $1', [lessonId]);

        // 4. Definisikan semua "slide" pelajaran sesuai desain Figma
        const steps = [
            { order: 1, type: 'intro_text', content: { title: "Selamat Datang di Fitur Belajar", text: "Salam! Selamat datang di fitur pembelajaran yang baru. Di sini, Anda dapat mempelajari berbagai konsep yang terkandung di balik Surat-Surat terpenting dan juga meninjau ulang ayat-ayat untuk menghafalnya dalam ingatan." } },
            { order: 2, type: 'verse_display', content: { verse_key: "1:5", show_play_button: true, transliteration: "iyyāka na'budu wa iyyāka nasta'īn" } },
            { order: 3, type: 'translation_display', content: { verse_key: "1:5" } },
            { order: 4, type: 'information_text', content: { title: "Informasi", text: "Ayat ini menonjolkan perlunya bimbingan Allah, menekankan ketergantungan pada rahmat-Nya untuk mendapatkan dukungan spiritual. Ayat ini juga menitikberatkan ketergantungan manusia pada kasih sayang Allah dan peran penting dalam mencari pertolongan-Nya untuk menghadapi tantangan hidup." } },
            { order: 5, type: 'quranic_verse_reference', content: { title: "Quranic Verse", text: "Dalam Surat Adz-Dzaariyaat ayat 56, Allah menyatakan bahwa Dia menciptakan alam semesta untuk beribadah kepada-Nya:\n\n“Dan Aku (Allah) tidak menciptakan jin dan manusia melainkan supaya mereka menyembah kepada-Ku.” (51:56)\n\nPara Rasul ditunjuk untuk membimbing manusia agar menyembah Allah semata, melarang segala bentuk pengkhianatan dari-Nya:\n\n“Kami tidak pernah mengutus seorang rasul pun sebelum kamu, wahai Nabi, kecuali Kami wahyukan kepadanya: “Tidak ada Tuhan yang patut disembah kecuali Aku, maka sembahlah Aku _saja_.” (21:25)" } },
            { order: 6, type: 'knowledge_review_mcq', content: { title: "Knowledge Review", question: "Apa saja sifat-sifat Allah yang disebutkan dalam Surat Al-Fatihah?", options: ["Maha Penyayang & Yang Maha Kaya", "Maha Besar & Maha Penyayang", "Maha Pengasih dan Maha Penyayang"], correct_index: 2 } },
            { order: 7, type: 'knowledge_review_boolean', content: { title: "Knowledge Review", question: "Ayat ini menceritakan tentang pentingnya meyakini ajaran Nabi SAW", correct_answer: false } },
            { order: 8, type: 'conclusion_text', content: { title: "Pengenalan Surat Al-fatihah secara keseluruhan:", text: "Surat Al-Fatihah, Ayat 1 digunakan sebagai fondasi untuk beribadah dan mencari bimbingan ilahi, menyoroti tema-tema mendasar tentang rasa syukur, kasih sayang, dan mengakui kendali Allah secara keseluruhan.\n\nSemoga Allah memberkati Anda dengan pengetahuan yang mendalam tentang Al-Quran saat Anda menjalani berbagai pelajaran.." } },
        ];

        // 5. Masukkan semua "slide" ke database
        for (const step of steps) {
            await client.query(
                'INSERT INTO lesson_steps (lesson_id, step_order, step_type, content) VALUES ($1, $2, $3, $4)',
                [lessonId, step.order, step.type, JSON.stringify(step.content)]
            );
        }

        await client.query('COMMIT');
        console.log(`\n🎉 Berhasil menanamkan ${steps.length} langkah untuk pelajaran Al-Fatihah.`);
    } catch (error) {
        await client.query('ROLLBACK');
        console.error('❌ ERROR saat proses seeding:', error);
    } finally {
        client.release();
        await pool.end();
    }
};

seedFatihahLesson();
