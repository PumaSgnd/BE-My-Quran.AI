// import/import-ayahs.js

const fs = require('fs');
const path = require('path');
const { Pool } = require('pg');
require('dotenv').config({ path: path.resolve(__dirname, '../.env') });

const pool = new Pool({
    user: process.env.DB_USER,
    host: process.env.DB_HOST,
    database: process.env.DB_DATABASE,
    password: process.env.DB_PASSWORD,
    port: process.env.DB_PORT,
});

const importAyahs = async () => {
    try {
        console.log('Membaca file data ayat...');
        const filePath = path.join(__dirname, '../data/quran-metadata-ayah.json');
        const dataBuffer = fs.readFileSync(filePath);
        const ayahsData = JSON.parse(dataBuffer.toString());
        const ayahsArray = Object.values(ayahsData);

        console.log(`Ditemukan ${ayahsArray.length} ayat untuk diimpor.`);
        const client = await pool.connect();
        console.log('Koneksi database berhasil. Memulai impor ayat...');

        await client.query('TRUNCATE TABLE ayahs RESTART IDENTITY;');
        console.log('Tabel ayahs berhasil dikosongkan.');

        // Proses impor dalam batch untuk efisiensi
        for (let i = 0; i < ayahsArray.length; i++) {
            const ayah = ayahsArray[i];
            const insertQuery = `
                INSERT INTO ayahs (id, surah_number, ayah_number, verse_key, words_count, text)
                VALUES ($1, $2, $3, $4, $5, $6)
            `;
            const values = [
                ayah.id,
                ayah.surah_number,
                ayah.ayah_number,
                ayah.verse_key,
                ayah.words_count,
                ayah.text,
            ];
            await client.query(insertQuery, values);
            
            // Memberi feedback setiap 100 ayat agar tidak terlalu ramai di konsol
            if ((i + 1) % 100 === 0) {
                console.log(`- Berhasil mengimpor ${i + 1} dari ${ayahsArray.length} ayat...`);
            }
        }

        console.log('\n🎉 Semua data ayat berhasil diimpor ke database!');
        client.release();

    } catch (error) {
        console.error('\n❌ TERJADI ERROR SAAT PROSES IMPOR AYAT:');
        console.error(error);
    } finally {
        await pool.end();
        console.log('Koneksi ke database ditutup.');
    }
};

importAyahs();
