// import/import-surahs.js

const fs = require('fs');
const path = require('path'); // Tambahkan ini untuk path yang lebih kuat
const { Pool } = require('pg');
require('dotenv').config({ path: path.resolve(__dirname, '../.env') }); // Sesuaikan path .env

// --- Konfigurasi Koneksi Database ---
const pool = new Pool({
    user: process.env.DB_USER,
    host: process.env.DB_HOST,
    database: process.env.DB_DATABASE,
    password: process.env.DB_PASSWORD,
    port: process.env.DB_PORT,
});

const importData = async () => {
    try {
        console.log('Membaca file data surah...');
        
        // --- INI BAGIAN YANG DISESUAIKAN ---
        // Path ini relatif dari lokasi skrip dijalankan
        const filePath = path.join(__dirname, '../data/quran-metadata-surah-name.json');
        const dataBuffer = fs.readFileSync(filePath);
        // ------------------------------------

        const dataJSON = dataBuffer.toString();
        const surahsData = JSON.parse(dataJSON);
        const surahsArray = Object.values(surahsData);

        console.log(`Ditemukan ${surahsArray.length} surah untuk diimpor.`);
        console.log('Menghubungkan ke database...');
        
        const client = await pool.connect();
        console.log('Koneksi berhasil. Memulai proses impor...');

        await client.query('TRUNCATE TABLE surahs RESTART IDENTITY;');
        console.log('Tabel surahs berhasil dikosongkan.');

        for (const surah of surahsArray) {
            const insertQuery = `
                INSERT INTO surahs (id, name, name_simple, name_arabic, revelation_order, revelation_place, verses_count, bismillah_pre)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
            `;
            const values = [
                surah.id,
                surah.name,
                surah.name_simple,
                surah.name_arabic,
                surah.revelation_order,
                surah.revelation_place,
                surah.verses_count,
                surah.bismillah_pre
            ];

            await client.query(insertQuery, values);
            console.log(`- Berhasil mengimpor Surah: ${surah.name_simple}`);
        }

        console.log('\n🎉 Semua data surah berhasil diimpor ke database!');
        client.release();

    } catch (error) {
        console.error('\n❌ TERJADI ERROR SAAT PROSES IMPOR:');
        console.error(error);
    } finally {
        await pool.end();
        console.log('Koneksi ke database ditutup.');
    }
};

importData();