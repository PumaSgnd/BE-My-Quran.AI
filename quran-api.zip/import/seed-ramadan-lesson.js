// import/seed-ramadan-lesson.js

const { Pool } = require('pg');
const path = require('path');
require('dotenv').config({ path: path.resolve(__dirname, '../.env') });

const pool = new Pool({
    user: process.env.DB_USER,
    host: process.env.DB_HOST,
    database: process.env.DB_DATABASE,
    password: process.env.DB_PASSWORD,
    port: process.env.DB_PORT,
});

const seedRamadanLesson = async () => {
    const client = await pool.connect();
    try {
        console.log('Memulai proses seeding pelajaran detail Topik Seri Ramadan...');
        await client.query('BEGIN');

        // 1. Cari ID dari materi induk "Seri Ramadan"
        const materialRes = await client.query("SELECT id FROM learning_materials WHERE action_value = 'ramadan'");
        if (materialRes.rows.length === 0) {
            throw new Error("Materi 'Seri Ramadan' (action_value: 'ramadan') tidak ditemukan. Jalankan seed-all-learning-content.js dulu.");
        }
        const materialId = materialRes.rows[0].id;
        console.log(`- Materi Induk "Seri Ramadan" ditemukan dengan ID: ${materialId}`);

        // 2. Definisikan 7 pelajaran di dalam Topik ini
        const ramadanLessons = [
            { title: "Keutamaan Puasa Ramadan", subtitle: "Dalil dan Hikmah", contentValue: "ramadan-01", order: 1 },
            { title: "Lailatul Qadar", subtitle: "Malam Seribu Bulan", contentValue: "ramadan-02", order: 2 },
            { title: "Zakat Fitrah", subtitle: "Penyucian Diri", contentValue: "ramadan-03", order: 3 },
            { title: "Amalan di Bulan Ramadan", subtitle: "Tarawih dan Tadarus", contentValue: "ramadan-04", order: 4 },
            { title: "Nuzulul Qur'an", subtitle: "Turunnya Al-Qur'an", contentValue: "ramadan-05", order: 5 },
            { title: "I'tikaf", subtitle: "Menetap di Masjid", contentValue: "ramadan-06", order: 6 },
            { title: "Idul Fitri", subtitle: "Hari Kemenangan", contentValue: "ramadan-07", order: 7 },
        ];

        const lessonIds = {}; // Untuk menyimpan ID pelajaran yang baru dibuat

        // 3. Masukkan semua pelajaran di atas ke tabel `lessons`
        for (const lesson of ramadanLessons) {
            const res = await client.query(
                "INSERT INTO lessons (material_id, title, subtitle, content_type, content_value, display_order) VALUES ($1, $2, $3, 'lesson', $4, $5) RETURNING id",
                [materialId, lesson.title, lesson.subtitle, lesson.contentValue, lesson.order]
            );
            lessonIds[lesson.contentValue] = res.rows[0].id;
        }
        console.log(`- Berhasil menanamkan ${ramadanLessons.length} pelajaran untuk Topik Seri Ramadan.`);

        // 4. Definisikan semua "slide" untuk pelajaran pertama ("ramadan-01")
        const firstLessonId = lessonIds['ramadan-01'];
        const steps = [
            { order: 1, type: 'intro_text', content: { title: "Pelajaran 1: Keutamaan Puasa Ramadan", text: "Ramadan adalah bulan yang penuh berkah. Mari kita pelajari dasar kewajiban berpuasa yang disebutkan dalam Al-Qur'an." } },
            { order: 2, type: 'verse_display', content: { verse_key: "2:183", show_play_button: true, transliteration: "yā ayyuhallażīna āmanụ kutiba 'alaikumuṣ-ṣiyāmu kamā kutiba 'alallażīna ming qablikum la'allakum tattaqụn" } },
            { order: 3, type: 'translation_display', content: { verse_key: "2:183" } },
            { order: 4, type: 'information_text', content: { title: "Informasi", text: "Ayat ini adalah landasan utama kewajiban berpuasa bagi umat Islam. Tujuannya bukan hanya menahan lapar dan haus, tetapi untuk mencapai tingkat ketakwaan yang lebih tinggi." } },
            { order: 5, type: 'knowledge_review_mcq', content: { title: "Knowledge Review", question: "Apa tujuan utama dari diwajibkannya puasa menurut QS. Al-Baqarah: 183?", options: ["Untuk merasakan penderitaan orang miskin", "Untuk menurunkan berat badan", "Agar kamu bertakwa"], correct_index: 2 } },
            { order: 6, type: 'conclusion_text', content: { title: "Selesai", text: "Anda telah menyelesaikan pelajaran tentang dasar-dasar puasa Ramadan. Semoga bermanfaat!" } }
        ];

        // 5. Masukkan semua "slide" ke database
        for (const step of steps) {
            await client.query(
                'INSERT INTO lesson_steps (lesson_id, step_order, step_type, content) VALUES ($1, $2, $3, $4)',
                [firstLessonId, step.order, step.type, JSON.stringify(step.content)]
            );
        }
        console.log(`- Berhasil menanamkan ${steps.length} slide untuk pelajaran pertama Topik Seri Ramadan.`);

        await client.query('COMMIT');
        console.log('\n✅ Proses seeding semua konten pelajaran Seri Ramadan selesai dengan sukses!');
    } catch (error) {
        await client.query('ROLLBACK');
        console.error('❌ ERROR saat proses seeding:', error);
    } finally {
        client.release();
        await pool.end();
    }
};

seedRamadanLesson();
