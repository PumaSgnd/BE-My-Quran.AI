// import/import-surah-info.js

const fs = require('fs');
const path = require('path');
const { Pool } = require('pg');
require('dotenv').config({ path: path.resolve(__dirname, '../.env') });

const pool = new Pool({
    user: process.env.DB_USER,
    host: process.env.DB_HOST,
    database: process.env.DB_DATABASE,
    password: process.env.DB_PASSWORD,
    port: process.env.DB_PORT,
});

const importSurahInfo = async () => {
    const client = await pool.connect();
    try {
        console.log('Membaca file data info surah (format baru)...');
        const filePath = path.join(__dirname, '../data/surah-info-id.json');
        const surahInfoData = JSON.parse(fs.readFileSync(filePath, 'utf8'));
        const surahInfoArray = Object.values(surahInfoData);

        await client.query('BEGIN');
        await client.query('TRUNCATE TABLE surah_info RESTART IDENTITY;');
        console.log('Tabel surah_info berhasil dikosongkan.');

        for (const info of surahInfoArray) {
            const query = `
                INSERT INTO surah_info (surah_id, short_text, long_text)
                VALUES ($1, $2, $3);
            `;
            // Sesuaikan dengan key di file JSON
            const values = [
                info.surah_number,
                info.short_text,
                info.text // Di JSON key-nya "text", kita masukkan ke kolom "long_text"
            ];
            await client.query(query, values);
            console.log(`- Info untuk Surah ID ${info.surah_number} berhasil diimpor.`);
        }
        
        await client.query('COMMIT');
        console.log(`\n🎉 Berhasil mengimpor info untuk ${surahInfoArray.length} surah.`);
    } catch (error) {
        await client.query('ROLLBACK');
        console.error('❌ ERROR saat impor info surah:', error);
    } finally {
        client.release();
        await pool.end();
    }
};

importSurahInfo();
