// import/seed-learning.js

const { Pool } = require('pg');
const path = require('path');
require('dotenv').config({ path: path.resolve(__dirname, '../.env') });

// Konfigurasi koneksi ke database PostgreSQL
const pool = new Pool({
    user: process.env.DB_USER,
    host: process.env.DB_HOST,
    database: process.env.DB_DATABASE,
    password: process.env.DB_PASSWORD,
    port: process.env.DB_PORT,
});

// Ini adalah data materi belajar yang akan kita masukkan.
// Setiap objek di dalam array ini akan menjadi satu baris di tabel `learning_materials`.
const learningMaterials = [
    {
        category: "pelajaran", // Materi ini akan muncul di tab "Pelajaran"
        title: "Hajj",
        subtitle: "8 Pelajaran",
        actionType: "OPEN_LESSON_LIST", // Perintah untuk frontend
        actionValue: "hajj",             // Parameter untuk perintah
        displayOrder: 1
    },
    {
        category: "pelajaran",
        title: "Seri Nabi Muhammad",
        subtitle: "15 Pelajaran",
        actionType: "OPEN_LESSON_LIST",
        actionValue: "sirah-nabawiyah",
        displayOrder: 2
    },
    {
        category: "pelajaran",
        title: "Surah-surah Al-Quran",
        subtitle: "114 Pelajaran",
        actionType: "OPEN_SURAH_LIST", // Jika diklik, frontend akan membuka halaman daftar surah
        actionValue: "all",
        displayOrder: 3
    },
    {
        category: "pelajaran",
        title: "Seri Ramadan",
        subtitle: "7 Pelajaran",
        actionType: "OPEN_LESSON_LIST",
        actionValue: "ramadan",
        displayOrder: 4
    },
    // Nanti, jika ada konten untuk tab "Menghafalkan", cukup tambahkan di sini
    // dengan category: "menghafalkan"
];

// Fungsi utama untuk menjalankan proses seeding
const seedLearningContent = async () => {
    const client = await pool.connect();
    try {
        console.log('Memulai proses seeding materi belajar...');
        await client.query('BEGIN'); // Memulai transaksi database

        // Mengosongkan tabel terlebih dahulu agar tidak ada data duplikat
        await client.query('TRUNCATE TABLE learning_materials RESTART IDENTITY;');
        console.log('Tabel learning_materials berhasil dikosongkan.');

        // Looping melalui setiap item di array `learningMaterials`
        for (const item of learningMaterials) {
            const query = `
                INSERT INTO learning_materials (category, title, subtitle, action_type, action_value, display_order)
                VALUES ($1, $2, $3, $4, $5, $6);
            `;
            // Memasukkan data ke database
            await client.query(query, [item.category, item.title, item.subtitle, item.actionType, item.actionValue, item.displayOrder]);
        }

        await client.query('COMMIT'); // Menyimpan semua perubahan jika berhasil
        console.log(`\n🎉 Berhasil menanamkan ${learningMaterials.length} item materi belajar.`);
    } catch (error) {
        await client.query('ROLLBACK'); // Batalkan semua perubahan jika terjadi error
        console.error('❌ ERROR saat proses seeding:', error);
    } finally {
        client.release(); // Melepaskan koneksi
        await pool.end();   // Menutup koneksi
    }
};

// Menjalankan fungsi seeder
seedLearningContent();
