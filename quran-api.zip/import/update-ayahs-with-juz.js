// import/update-ayahs-with-juz.js
const fs = require('fs');
const path = require('path');
const { Pool } = require('pg');
require('dotenv').config({ path: path.resolve(__dirname, '../.env') });

// --- INI BAGIAN YANG DIPERBAIKI ---
const pool = new Pool({
    user: process.env.DB_USER,
    host: process.env.DB_HOST,
    database: process.env.DB_DATABASE,
    password: process.env.DB_PASSWORD,
    port: process.env.DB_PORT,
});
// ------------------------------------

const updateAyahsWithJuz = async () => {
    const client = await pool.connect();
    try {
        console.log('Membaca file data info juz untuk mapping...');
        const filePath = path.join(__dirname, '../data/quran-metadata-juz.json');
        const juzData = JSON.parse(fs.readFileSync(filePath, 'utf8'));
        const juzArray = Object.values(juzData);

        await client.query('BEGIN');
        console.log('Memulai proses update kolom juz_number di tabel ayahs...');

        for (const juz of juzArray) {
            const juzNumber = juz.juz_number;
            const verseMapping = juz.verse_mapping;

            for (const surahNumber in verseMapping) {
                const verseRange = verseMapping[surahNumber].split('-');
                const startVerse = parseInt(verseRange[0]);
                const endVerse = parseInt(verseRange[1]);

                const updateQuery = `
                    UPDATE ayahs 
                    SET juz_number = $1 
                    WHERE surah_number = $2 AND ayah_number BETWEEN $3 AND $4;
                `;
                await client.query(updateQuery, [juzNumber, surahNumber, startVerse, endVerse]);
            }
            console.log(`- Selesai mapping untuk Juz ${juzNumber}`);
        }

        await client.query('COMMIT');
        console.log('🎉 Semua ayat berhasil di-update dengan nomor juz!');

    } catch (error) {
        await client.query('ROLLBACK');
        console.error('❌ ERROR saat update ayat dengan juz:', error);
    } finally {
        client.release();
        await pool.end();
    }
};

updateAyahsWithJuz();
