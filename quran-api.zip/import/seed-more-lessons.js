// import/seed-more-lessons.js

const { Pool } = require('pg');
const path = require('path');
require('dotenv').config({ path: path.resolve(__dirname, '../.env') });

const pool = new Pool({
    user: process.env.DB_USER,
    host: process.env.DB_HOST,
    database: process.env.DB_DATABASE,
    password: process.env.DB_PASSWORD,
    port: process.env.DB_PORT,
});

const lessonsToAdd = [
    { surahId: 36, title: 'Surat Yaseen', subtitle: '83 Ayat', contentValue: 'surah-36' },
    { surahId: 67, title: 'Surat Al-Mulk', subtitle: '30 Ayat', contentValue: 'surah-67' },
];

const seedMoreLessons = async () => {
    const client = await pool.connect();
    try {
        console.log('Memulai proses seeding pelajaran tambahan...');
        await client.query('BEGIN');

        const materialRes = await client.query("SELECT id FROM learning_materials WHERE action_value = 'all'");
        if (materialRes.rows.length === 0) {
            throw new Error("Materi 'Quranic Surahs' tidak ditemukan. Jalankan seed-learning.js dulu.");
        }
        const materialId = materialRes.rows[0].id;

        for (const lesson of lessonsToAdd) {
            const lessonQuery = `
                INSERT INTO lessons (material_id, title, subtitle, content_type, content_value, display_order)
                VALUES ($1, $2, $3, 'lesson', $4, $5)
                ON CONFLICT DO NOTHING;
            `;
            // Kita set display_order sesuai nomor surah agar urut
            await client.query(lessonQuery, [materialId, lesson.title, lesson.subtitle, lesson.contentValue, lesson.surahId]);
        }

        await client.query('COMMIT');
        console.log(`\n🎉 Berhasil menanamkan ${lessonsToAdd.length} pelajaran tambahan.`);
    } catch (error) {
        await client.query('ROLLBACK');
        console.error('❌ ERROR saat proses seeding:', error);
    } finally {
        client.release();
        await pool.end();
    }
};

seedMoreLessons();
