// import/import-transliteration.js
require('dotenv').config();
const fs = require('fs');
const path = require('path');

// Support dua lokasi config (tergantung struktur repo kamu)
let db;
try { db = require('../config/db'); }
catch { db = require('../src/config/db'); }

function formatUI(raw) {
    if (!raw) return '';
    let s = String(raw);
    s = s.replace(/[‘’`´]/g, "'");  // normalisasi apostrof
    s = s.replace(/\s{2,}/g, ' ').trim(); // rapikan spasi
    s = s.toLowerCase();            // konsisten kecil semua
    s = s.replace(/\s*-\s*/g, '-'); // rapikan spasi sekitar hyphen
    return s;
}

(async () => {
    try {
        const jsonPath = process.argv[2];
        if (!jsonPath) {
            console.error('Usage: node import/import-transliteration.js data/syllables-transliteration-old.json');
            process.exit(1);
        }

        const abs = path.resolve(jsonPath);
        console.log('[dotenv] loaded. Reading:', abs);

        const raw = fs.readFileSync(abs, 'utf8');
        const map = JSON.parse(raw); // { "s:a": "text", ... }
        const verseKeys = Object.keys(map);
        console.log(`Parsed ${verseKeys.length} transliteration rows from ${abs}`);

        if (!verseKeys.length) {
            console.error('No data parsed. Check your JSON format.');
            process.exit(1);
        }

        // Ambil ayah untuk semua verse_key biar 1x query
        const ayahRes = await db.query(
            `SELECT id, verse_key, surah_number, ayah_number
       FROM ayahs
       WHERE verse_key = ANY($1)`,
            [verseKeys]
        );

        const byVerse = new Map();
        for (const row of ayahRes.rows) byVerse.set(row.verse_key, row);

        let inserted = 0, updated = 0, skipped = 0;

        // Upsert per batch sederhana (boleh juga di-bulk, tapi ini jelas)
        for (const vk of verseKeys) {
            const ay = byVerse.get(vk);
            if (!ay) { skipped++; continue; }

            const textRaw = String(map[vk] || '');
            const textUI = formatUI(textRaw);

            await db.query(
                `INSERT INTO transliterations
           (ayah_id, verse_key, surah_number, ayah_number, text_raw, text_ui, source)
         VALUES ($1,$2,$3,$4,$5,$6,'qul-old')
         ON CONFLICT (ayah_id) DO UPDATE
           SET text_raw = EXCLUDED.text_raw,
               text_ui  = EXCLUDED.text_ui,
               source   = EXCLUDED.source,
               updated_at = now()`,
                [ay.id, vk, ay.surah_number, ay.ayah_number, textRaw, textUI]
            ).then(r => {
                // Heuristik kecil: kalau rowCount=1 pada INSERT → treat as inserted.
                inserted++;
            }).catch(() => {
                updated++; // fallback, tapi sebenarnya ON CONFLICT tidak expose updated/inserted.
            });
        }

        console.log(`✅ Done. Upserted: ${inserted}, Skipped (no ayah): ${skipped}`);
        process.exit(0);
    } catch (err) {
        console.error('Import error:', err);
        process.exit(1);
    }
})();
