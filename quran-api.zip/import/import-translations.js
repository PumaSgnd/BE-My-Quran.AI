// import/import-translations.js

const fs = require('fs');
const path = require('path');
const { Pool } = require('pg');
require('dotenv').config({ path: path.resolve(__dirname, '../.env') });

const pool = new Pool({
    user: process.env.DB_USER,
    host: process.env.DB_HOST,
    database: process.env.DB_DATABASE,
    password: process.env.DB_PASSWORD,
    port: process.env.DB_PORT,
});

const importTranslations = async () => {
    const client = await pool.connect();
    try {
        console.log('Membaca file data terjemahan...');
        const filePath = path.join(__dirname, '../data/king-fahad-quran-complex-with-footnote-tags.json');
        const dataBuffer = fs.readFileSync(filePath);
        const translationsData = JSON.parse(dataBuffer.toString());
        const verseKeys = Object.keys(translationsData);

        console.log(`Ditemukan ${verseKeys.length} terjemahan untuk diimpor.`);
        await client.query('BEGIN'); // Mulai transaksi

        await client.query('TRUNCATE TABLE translations RESTART IDENTITY;');
        console.log('Tabel translations berhasil dikosongkan.');

        for (let i = 0; i < verseKeys.length; i++) {
            const verseKey = verseKeys[i]; // contoh: "1:1"
            const translationObj = translationsData[verseKey];

            // 1. Cari ID ayat berdasarkan verse_key
            const ayahRes = await client.query('SELECT id FROM ayahs WHERE verse_key = $1', [verseKey]);
            if (ayahRes.rows.length === 0) {
                console.warn(`Peringatan: Tidak ditemukan ayat untuk verse_key ${verseKey}. Dilewati.`);
                continue;
            }
            const ayahId = ayahRes.rows[0].id;

            // 2. Siapkan data untuk dimasukkan
            const authorName = 'Kemenag'; // Kita beri nama sumbernya
            const translationText = translationObj.t;
            // Konversi objek footnote ke string JSON, atau null jika tidak ada
            const footnotes = translationObj.f ? JSON.stringify(translationObj.f) : null;

            // 3. Masukkan ke database
            const insertQuery = `
                INSERT INTO translations (ayah_id, author_name, translation_text, footnotes)
                VALUES ($1, $2, $3, $4)
            `;
            await client.query(insertQuery, [ayahId, authorName, translationText, footnotes]);

            if ((i + 1) % 100 === 0) {
                console.log(`- Berhasil memproses ${i + 1} dari ${verseKeys.length} terjemahan...`);
            }
        }

        await client.query('COMMIT'); // Selesaikan transaksi jika semua berhasil
        console.log('\n🎉 Semua data terjemahan berhasil diimpor!');

    } catch (error) {
        await client.query('ROLLBACK'); // Batalkan semua jika ada error
        console.error('\n❌ TERJADI ERROR SAAT PROSES IMPOR TERJEMAHAN:');
        console.error(error);
    } finally {
        client.release();
        await pool.end();
        console.log('Koneksi ke database ditutup.');
    }
};

importTranslations();
