// import/seed-all-learning-content.js

const { Pool } = require('pg');
const path = require('path');
require('dotenv').config({ path: path.resolve(__dirname, '../.env') });

const pool = new Pool({
    user: process.env.DB_USER,
    host: process.env.DB_HOST,
    database: process.env.DB_DATABASE,
    password: process.env.DB_PASSWORD,
    port: process.env.DB_PORT,
});

const seedAllLearningContent = async () => {
    const client = await pool.connect();
    try {
        console.log('Memulai proses seeding SEMUA konten belajar dari awal...');
        await client.query('BEGIN');

        // 1. BERSIHKAN SEMUA DATA LAMA DENGAN TUNTAS
        console.log('- Menghapus data lama dari lesson_steps, lessons, dan learning_materials...');
        // Perintah TRUNCATE akan menghapus semua data dengan cepat dan me-reset ID. CASCADE memastikan relasi ikut terhapus.
        await client.query('TRUNCATE TABLE lesson_steps, lessons, learning_materials RESTART IDENTITY CASCADE;');
        console.log('- Semua tabel belajar berhasil dikosongkan.');

        // 2. MASUKKAN DATA TOPIK UTAMA (learning_materials)
        const learningMaterials = [
            { category: "pelajaran", title: "Hajj", subtitle: "8 Pelajaran", actionType: "OPEN_LESSON_LIST", actionValue: "hajj", displayOrder: 1 },
            { category: "pelajaran", title: "Seri Nabi Muhammad", subtitle: "15 Pelajaran", actionType: "OPEN_LESSON_LIST", actionValue: "sirah-nabawiyah", displayOrder: 2 },
            { category: "pelajaran", title: "Surah-surah Al-Quran", subtitle: "3 Pelajaran", actionType: "OPEN_SURAH_LIST", actionValue: "all", displayOrder: 3 },
            { category: "pelajaran", title: "Seri Ramadan", subtitle: "7 Pelajaran", actionType: "OPEN_LESSON_LIST", actionValue: "ramadan", displayOrder: 4 },
        ];
        for (const item of learningMaterials) {
            await client.query(
                'INSERT INTO learning_materials (category, title, subtitle, action_type, action_value, display_order) VALUES ($1, $2, $3, $4, $5, $6)',
                [item.category, item.title, item.subtitle, item.actionType, item.actionValue, item.displayOrder]
            );
        }
        console.log(`- Berhasil menanamkan ${learningMaterials.length} topik utama.`);

        // Ambil ID dari "Surah-surah Al-Quran" untuk digunakan nanti
        const materialRes = await client.query("SELECT id FROM learning_materials WHERE action_value = 'all'");
        const quranSurahsMaterialId = materialRes.rows[0].id;

        // 3. MASUKKAN DATA PELAJARAN (lessons) UNTUK SETIAP SURAH
        const lessonsToAdd = [
            { surahId: 1, title: 'Surat Al-Fatihah', subtitle: '7 Ayat', contentValue: 'surah-1' },
            { surahId: 36, title: 'Surat Yaseen', subtitle: '83 Ayat', contentValue: 'surah-36' },
            { surahId: 67, title: 'Surat Al-Mulk', subtitle: '30 Ayat', contentValue: 'surah-67' },
        ];
        const lessonIds = {}; // Untuk menyimpan ID pelajaran yang baru dibuat
        for (const lesson of lessonsToAdd) {
            const res = await client.query(
                "INSERT INTO lessons (material_id, title, subtitle, content_type, content_value, display_order) VALUES ($1, $2, $3, 'lesson', $4, $5) RETURNING id",
                [quranSurahsMaterialId, lesson.title, lesson.subtitle, lesson.contentValue, lesson.surahId]
            );
            // Simpan ID pelajaran yang baru dibuat, diindeks berdasarkan nomor surahnya
            lessonIds[lesson.surahId] = res.rows[0].id;
        }
        console.log(`- Berhasil menanamkan ${lessonsToAdd.length} pelajaran surah.`);

        // 4. MASUKKAN "SLIDE" (lesson_steps) UNTUK SETIAP PELAJARAN

        // --- Konten Detail untuk Al-Fatihah ---
        const fatihahSteps = [
            { order: 1, type: 'intro_text', content: { title: "Selamat Datang di Fitur Belajar", text: "Salam! Selamat datang di fitur pembelajaran yang baru. Di sini, Anda dapat mempelajari berbagai konsep yang terkandung di balik Surat-Surat terpenting dan juga meninjau ulang ayat-ayat untuk menghafalnya dalam ingatan." } },
            { order: 2, type: 'verse_display', content: { verse_key: "1:5", show_play_button: true, transliteration: "iyyāka na'budu wa iyyāka nasta'īn" } },
            { order: 3, type: 'translation_display', content: { verse_key: "1:5" } },
            { order: 4, type: 'information_text', content: { title: "Informasi", text: "Ayat ini menonjolkan perlunya bimbingan Allah, menekankan ketergantungan pada rahmat-Nya untuk mendapatkan dukungan spiritual. Ayat ini juga menitikberatkan ketergantungan manusia pada kasih sayang Allah dan peran penting dalam mencari pertolongan-Nya untuk menghadapi tantangan hidup." } },
            { order: 5, type: 'quranic_verse_reference', content: { title: "Quranic Verse", text: "Dalam Surat Adz-Dzaariyaat ayat 56, Allah menyatakan bahwa Dia menciptakan alam semesta untuk beribadah kepada-Nya:\n\n“Dan Aku (Allah) tidak menciptakan jin dan manusia melainkan supaya mereka menyembah kepada-Ku.” (51:56)\n\nPara Rasul ditunjuk untuk membimbing manusia agar menyembah Allah semata, melarang segala bentuk pengkhianatan dari-Nya:\n\n“Kami tidak pernah mengutus seorang rasul pun sebelum kamu, wahai Nabi, kecuali Kami wahyukan kepadanya: “Tidak ada Tuhan yang patut disembah kecuali Aku, maka sembahlah Aku _saja_.” (21:25)" } },
            { order: 6, type: 'knowledge_review_mcq', content: { title: "Knowledge Review", question: "Apa saja sifat-sifat Allah yang disebutkan dalam Surat Al-Fatihah?", options: ["Maha Penyayang & Yang Maha Kaya", "Maha Besar & Maha Penyayang", "Maha Pengasih dan Maha Penyayang"], correct_index: 2 } },
            { order: 7, type: 'knowledge_review_boolean', content: { title: "Knowledge Review", question: "Ayat ini menceritakan tentang pentingnya meyakini ajaran Nabi SAW", correct_answer: false } },
            { order: 8, type: 'conclusion_text', content: { title: "Pengenalan Surat Al-fatihah secara keseluruhan:", text: "Surat Al-Fatihah, Ayat 1 digunakan sebagai fondasi untuk beribadah dan mencari bimbingan ilahi, menyoroti tema-tema mendasar tentang rasa syukur, kasih sayang, dan mengakui kendali Allah secara keseluruhan.\n\nSemoga Allah memberkati Anda dengan pengetahuan yang mendalam tentang Al-Quran saat Anda menjalani berbagai pelajaran.." } },
        ];
        for (const step of fatihahSteps) {
            // Gunakan ID pelajaran Al-Fatihah (surahId: 1) yang sudah kita simpan
            await client.query('INSERT INTO lesson_steps (lesson_id, step_order, step_type, content) VALUES ($1, $2, $3, $4)', [lessonIds[1], step.order, step.type, JSON.stringify(step.content)]);
        }
        console.log(`- Berhasil menanamkan ${fatihahSteps.length} slide untuk Al-Fatihah.`);

        // --- Konten Placeholder untuk Yaseen ---
        const yaseenSteps = [
            { order: 1, type: 'intro_text', content: { title: "Pengantar Surat Yaseen", text: "Ini adalah pelajaran tentang keutamaan Surat Yaseen." } },
            { order: 2, type: 'verse_display', content: { verse_key: "36:58", show_play_button: true } },
            { order: 3, type: 'conclusion_text', content: { title: "Selesai", text: "Anda telah menyelesaikan pelajaran singkat Surat Yaseen." } }
        ];
        for (const step of yaseenSteps) {
            // Gunakan ID pelajaran Yaseen (surahId: 36) yang sudah kita simpan
            await client.query('INSERT INTO lesson_steps (lesson_id, step_order, step_type, content) VALUES ($1, $2, $3, $4)', [lessonIds[36], step.order, step.type, JSON.stringify(step.content)]);
        }
        console.log(`- Berhasil menanamkan ${yaseenSteps.length} slide untuk Yaseen.`);

        // --- Konten Placeholder untuk Al-Mulk ---
        const mulkSteps = [
            { order: 1, type: 'intro_text', content: { title: "Pengantar Surat Al-Mulk", text: "Ini adalah pelajaran tentang keutamaan Surat Al-Mulk." } },
            { order: 2, type: 'verse_display', content: { verse_key: "67:1", show_play_button: true } },
            { order: 3, type: 'conclusion_text', content: { title: "Selesai", text: "Anda telah menyelesaikan pelajaran singkat Surat Al-Mulk." } }
        ];
        for (const step of mulkSteps) {
            // Gunakan ID pelajaran Al-Mulk (surahId: 67) yang sudah kita simpan
            await client.query('INSERT INTO lesson_steps (lesson_id, step_order, step_type, content) VALUES ($1, $2, $3, $4)', [lessonIds[67], step.order, step.type, JSON.stringify(step.content)]);
        }
        console.log(`- Berhasil menanamkan ${mulkSteps.length} slide untuk Al-Mulk.`);

        await client.query('COMMIT');
        console.log('\n✅ Proses seeding semua konten belajar selesai dengan sukses!');
    } catch (error) {
        await client.query('ROLLBACK');
        console.error('❌ ERROR saat proses seeding:', error);
    } finally {
        client.release();
        await pool.end();
    }
};

seedAllLearningContent();
