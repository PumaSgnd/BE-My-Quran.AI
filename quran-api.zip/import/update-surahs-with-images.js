// import/update-surahs-with-images.js

const { Pool } = require('pg');
const path = require('path');
require('dotenv').config({ path: path.resolve(__dirname, '../.env') });

const pool = new Pool({
    user: process.env.DB_USER,
    host: process.env.DB_HOST,
    database: process.env.DB_DATABASE,
    password: process.env.DB_PASSWORD,
    port: process.env.DB_PORT,
});

// Daftar gambar placeholder yang indah dari Unsplash
const imageUrls = [
    'https://images.unsplash.com/photo-1557682250-33bd709cbe85?q=80&w=2070&auto=format&fit=crop', // Gradasi ungu-biru
    'https://images.unsplash.com/photo-1554034483-263cf2358181?q=80&w=1887&auto=format&fit=crop', // Gradasi pastel
    'https://images.unsplash.com/photo-1579546929518-9e396f3cc809?q=80&w=2070&auto=format&fit=crop', // Gradasi pelangi
    'https://images.unsplash.com/photo-1528459801416-a9e53bbf4e17?q=80&w=1912&auto=format&fit=crop', // Gradasi pink-kuning
    'https://images.unsplash.com/photo-1500964757637-c85e8a162699?q=80&w=2103&auto=format&fit=crop'  // Pemandangan alam
];

const updateSurahImages = async () => {
    const client = await pool.connect();
    try {
        console.log('Memulai proses update gambar untuk surah...');
        await client.query('BEGIN');

        // Looping untuk setiap surah dari 1 sampai 114
        for (let i = 1; i <= 114; i++) {
            // Pilih gambar secara bergiliran dari daftar di atas
            // Operator % (modulo) memastikan kita tidak kehabisan gambar
            const imageUrl = imageUrls[i % imageUrls.length];

            const updateQuery = `
                UPDATE surahs 
                SET image_url = $1 
                WHERE id = $2;
            `;
            // Menjalankan query untuk mengupdate baris surah yang sesuai
            await client.query(updateQuery, [imageUrl, i]);
        }

        await client.query('COMMIT'); // Simpan semua perubahan
        console.log('\n🎉 Semua surah berhasil di-update dengan image_url!');

    } catch (error) {
        await client.query('ROLLBACK'); // Batalkan jika ada error
        console.error('\n❌ TERJADI ERROR SAAT PROSES UPDATE:', error);
    } finally {
        client.release();
        await pool.end();
    }
};

// Menjalankan fungsi utama
updateSurahImages();
