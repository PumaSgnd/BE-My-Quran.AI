// import/update-surahs-with-translation.js

const { Pool } = require('pg');
const path = require('path');
require('dotenv').config({ path: path.resolve(__dirname, '../.env') });

const pool = new Pool({
    user: process.env.DB_USER,
    host: process.env.DB_HOST,
    database: process.env.DB_DATABASE,
    password: process.env.DB_PASSWORD,
    port: process.env.DB_PORT,
});

// Data terjemahan nama 114 surah
const translations = [
    { id: 1, translation: "Pembukaan" }, { id: 2, translation: "Sapi Betina" },
    { id: 3, translation: "Keluarga Imran" }, { id: 4, translation: "Wanita" },
    { id: 5, translation: "Hidangan" }, { id: 6, translation: "Binatang Ternak" },
    { id: 7, translation: "Tempat Tertinggi" }, { id: 8, translation: "Rampasan Perang" },
    { id: 9, translation: "Pengampunan" }, { id: 10, translation: "Nabi Yunus" },
    { id: 11, translation: "Nabi Hud" }, { id: 12, translation: "Nabi Yusuf" },
    { id: 13, translation: "Guruh" }, { id: 14, translation: "Nabi Ibrahim" },
    { id: 15, translation: "Al-Hijr" }, { id: 16, translation: "Lebah" },
    { id: 17, translation: "Perjalanan Malam" }, { id: 18, translation: "Gua" },
    { id: 19, translation: "Maryam" }, { id: 20, translation: "Thaha" },
    { id: 21, translation: "Para Nabi" }, { id: 22, translation: "Haji" },
    { id: 23, translation: "Orang-Orang Mukmin" }, { id: 24, translation: "Cahaya" },
    { id: 25, translation: "Pembeda" }, { id: 26, translation: "Para Penyair" },
    { id: 27, translation: "Semut" }, { id: 28, translation: "Kisah-Kisah" },
    { id: 29, translation: "Laba-Laba" }, { id: 30, translation: "Bangsa Romawi" },
    { id: 31, translation: "Luqman" }, { id: 32, translation: "Sujud" },
    { id: 33, translation: "Golongan-Golongan yang Bersekutu" }, { id: 34, translation: "Kaum Saba'" },
    { id: 35, translation: "Pencipta" }, { id: 36, translation: "Yasin" },
    { id: 37, translation: "Barisan-Barisan" }, { id: 38, translation: "Shad" },
    { id: 39, translation: "Rombongan-Rombongan" }, { id: 40, translation: "Maha Pengampun" },
    { id: 41, translation: "Yang Dijelaskan" }, { id: 42, translation: "Musyawarah" },
    { id: 43, translation: "Perhiasan" }, { id: 44, translation: "Kabut" },
    { id: 45, translation: "Yang Berlutut" }, { id: 46, translation: "Bukit Pasir" },
    { id: 47, translation: "Nabi Muhammad" }, { id: 48, translation: "Kemenangan" },
    { id: 49, translation: "Kamar-Kamar" }, { id: 50, translation: "Qaf" },
    { id: 51, translation: "Angin yang Menerbangkan" }, { id: 52, translation: "Bukit" },
    { id: 53, translation: "Bintang" }, { id: 54, translation: "Bulan" },
    { id: 55, translation: "Maha Pemurah" }, { id: 56, translation: "Hari Kiamat" },
    { id: 57, translation: "Besi" }, { id: 58, translation: "Wanita yang Mengajukan Gugatan" },
    { id: 59, translation: "Pengusiran" }, { id: 60, translation: "Wanita yang Diuji" },
    { id: 61, translation: "Barisan" }, { id: 62, translation: "Hari Jum'at" },
    { id: 63, translation: "Orang-Orang Munafik" }, { id: 64, translation: "Hari Dinampakkan Kesalahan" },
    { id: 65, translation: "Talak" }, { id: 66, translation: "Mengharamkan" },
    { id: 67, translation: "Kerajaan" }, { id: 68, translation: "Pena" },
    { id: 69, translation: "Hari Kiamat" }, { id: 70, translation: "Tempat Naik" },
    { id: 71, translation: "Nabi Nuh" }, { id: 72, translation: "Jin" },
    { id: 73, translation: "Orang yang Berselimut" }, { id: 74, translation: "Orang yang Berkemul" },
    { id: 75, translation: "Hari Kiamat" }, { id: 76, translation: "Manusia" },
    { id: 77, translation: "Malaikat-Malaikat yang Diutus" }, { id: 78, translation: "Berita Besar" },
    { id: 79, translation: "Malaikat-Malaikat yang Mencabut" }, { id: 80, translation: "Bermuka Masam" },
    { id: 81, translation: "Menggulung" }, { id: 82, translation: "Terbelah" },
    { id: 83, translation: "Orang-Orang Curang" }, { id: 84, translation: "Terbelah" },
    { id: 85, translation: "Gugusan Bintang" }, { id: 86, translation: "Yang Datang di Malam Hari" },
    { id: 87, translation: "Yang Paling Tinggi" }, { id: 88, translation: "Hari Pembalasan" },
    { id: 89, translation: "Fajar" }, { id: 90, translation: "Negeri" },
    { id: 91, translation: "Matahari" }, { id: 92, translation: "Malam" },
    { id: 93, translation: "Waktu Dhuha" }, { id: 94, translation: "Melapangkan" },
    { id: 95, translation: "Buah Tin" }, { id: 96, translation: "Segumpal Darah" },
    { id: 97, translation: "Kemuliaan" }, { id: 98, translation: "Bukti" },
    { id: 99, translation: "Guncangan" }, { id: 100, translation: "Kuda Perang" },
    { id: 101, translation: "Hari Kiamat" }, { id: 102, translation: "Bermegah-Megahan" },
    { id: 103, translation: "Masa" }, { id: 104, translation: "Pengumpat" },
    { id: 105, translation: "Gajah" }, { id: 106, translation: "Suku Quraisy" },
    { id: 107, translation: "Barang-Barang yang Berguna" }, { id: 108, translation: "Nikmat yang Banyak" },
    { id: 109, translation: "Orang-Orang Kafir" }, { id: 110, translation: "Pertolongan" },
    { id: 111, translation: "Gejolak Api" }, { id: 112, translation: "Memurnikan Keesaan Allah" },
    { id: 113, translation: "Waktu Subuh" }, { id: 114, translation: "Manusia" }
];

const updateSurahTranslations = async () => {
    const client = await pool.connect();
    try {
        console.log('Memulai proses update arti nama surah...');
        await client.query('BEGIN');

        for (const item of translations) {
            const updateQuery = `
                UPDATE surahs 
                SET name_translation_id = $1 
                WHERE id = $2;
            `;
            await client.query(updateQuery, [item.translation, item.id]);
            console.log(`- Surah ID ${item.id} diupdate dengan arti: "${item.translation}"`);
        }

        await client.query('COMMIT');
        console.log('\n🎉 Semua arti nama surah berhasil di-update!');

    } catch (error) {
        await client.query('ROLLBACK');
        console.error('\n❌ TERJADI ERROR SAAT PROSES UPDATE:', error);
    } finally {
        client.release();
        await pool.end();
    }
};

updateSurahTranslations();
