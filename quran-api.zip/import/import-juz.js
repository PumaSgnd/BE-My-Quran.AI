// import/import-juz.js
const fs = require('fs');
const path = require('path');
const { Pool } = require('pg');
require('dotenv').config({ path: path.resolve(__dirname, '../.env') });

// --- INI BAGIAN YANG DIPERBAIKI ---
const pool = new Pool({
    user: process.env.DB_USER,
    host: process.env.DB_HOST,
    database: process.env.DB_DATABASE,
    password: process.env.DB_PASSWORD,
    port: process.env.DB_PORT,
});
// ------------------------------------

const importJuzInfo = async () => {
    const client = await pool.connect();
    try {
        console.log('Membaca file data info juz...');
        const filePath = path.join(__dirname, '../data/quran-metadata-juz.json');
        const juzData = JSON.parse(fs.readFileSync(filePath, 'utf8'));
        const juzArray = Object.values(juzData);

        await client.query('BEGIN');
        await client.query('TRUNCATE TABLE juz RESTART IDENTITY CASCADE;'); // Tambah CASCADE
        console.log('Tabel juz berhasil dikosongkan.');

        for (const juz of juzArray) {
            const query = `
                INSERT INTO juz (juz_number, verses_count, first_verse_key, last_verse_key, verse_mapping)
                VALUES ($1, $2, $3, $4, $5);
            `;
            const values = [
                juz.juz_number,
                juz.verses_count,
                juz.first_verse_key,
                juz.last_verse_key,
                JSON.stringify(juz.verse_mapping)
            ];
            await client.query(query, values);
        }

        await client.query('COMMIT');
        console.log(`🎉 Berhasil mengimpor info untuk ${juzArray.length} juz.`);
    } catch (error) {
        await client.query('ROLLBACK');
        console.error('❌ ERROR saat impor info juz:', error);
    } finally {
        client.release();
        await pool.end();
    }
};

importJuzInfo();
