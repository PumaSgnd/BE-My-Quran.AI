// import/seed-content.js

const { Pool } = require('pg');
const path = require('path');
require('dotenv').config({ path: path.resolve(__dirname, '../.env') });

const pool = new Pool({
    user: process.env.DB_USER,
    host: process.env.DB_HOST,
    database: process.env.DB_DATABASE,
    password: process.env.DB_PASSWORD,
    port: process.env.DB_PORT,
});

// Data konten awal berdasarkan desain Figma
const featuredContent = [
    // --- 3 Banner Atas ---
    {
        title: "Pemandangan Mekah",
        subtitle: null,
        imageUrl: "https://images.unsplash.com/photo-1583911860202-8381822557a2?q=80&w=1887&auto=format&fit=crop",
        actionType: "OPEN_URL",
        actionValue: "https://unsplash.com/s/photos/mecca",
        displayOrder: 1,
        screenLocation: "temukan_banner"
    },
    {
        title: "Masjid Nabawi",
        subtitle: null,
        imageUrl: "https://images.unsplash.com/photo-1600185980994-96035539a2ce?q=80&w=1887&auto=format&fit=crop",
        actionType: "OPEN_URL",
        actionValue: "https://unsplash.com/s/photos/masjid-nabawi",
        displayOrder: 2,
        screenLocation: "temukan_banner"
    },
    {
        title: "Seni Islami",
        subtitle: null,
        imageUrl: "https://images.unsplash.com/photo-1554189097-c9abf363c1d5?q=80&w=1887&auto=format&fit=crop",
        actionType: "OPEN_URL",
        actionValue: "https://unsplash.com/s/photos/islamic-art",
        displayOrder: 3,
        screenLocation: "temukan_banner"
    },
    // --- Kartu-kartu Utama ---
    {
        title: "Belajar",
        subtitle: "Surat-surat Penting, Sumber Daya, Menghafalkan",
        imageUrl: "https://images.unsplash.com/photo-1528834379234-1de758c27117?q=80&w=2070&auto=format&fit=crop",
        actionType: "OPEN_LEARN_SECTION",
        actionValue: "main",
        displayOrder: 4,
        screenLocation: "temukan_main"
    },
    {
        title: "Menghafalkan",
        subtitle: "Komunitas untuk menghafal",
        imageUrl: "https://images.unsplash.com/photo-1593108851993-72274a4a4993?q=80&w=2070&auto=format&fit=crop",
        actionType: "OPEN_MEMORIZE_SECTION",
        actionValue: "community",
        displayOrder: 5,
        screenLocation: "temukan_main"
    },
    {
        title: "Selami lebih dalam",
        subtitle: "Al-Fatihah, Ayat 1",
        imageUrl: "https://images.unsplash.com/photo-1604271424141-593c5a66a1f8?q=80&w=2070&auto=format&fit=crop",
        actionType: "DEEP_DIVE_AYAH",
        actionValue: "1:1",
        displayOrder: 6,
        screenLocation: "temukan_main"
    },
    {
        title: "Baca",
        subtitle: "Al-Qur'an di ujung jari Anda",
        imageUrl: "https://images.unsplash.com/photo-1598449332213-0591207c7a0d?q=80&w=2070&auto=format&fit=crop",
        actionType: "OPEN_LAST_READ",
        actionValue: "last_read",
        displayOrder: 7,
        screenLocation: "temukan_main"
    },
    {
        title: "Ibadah harian",
        subtitle: "Doa Malaikat untuk Orang-ora...",
        imageUrl: "https://images.unsplash.com/photo-1584267385494-9fdd9a71ad75?q=80&w=2070&auto=format&fit=crop",
        actionType: "OPEN_ARTICLE",
        actionValue: "doa-malaikat",
        displayOrder: 8,
        screenLocation: "temukan_main"
    },
    {
        title: "Ayat Harian",
        subtitle: "Al-Mulk, Ayat 15",
        imageUrl: "https://images.unsplash.com/photo-1614539954392-81816365a6f2?q=80&w=1932&auto=format&fit=crop",
        actionType: "OPEN_DAILY_AYAH",
        actionValue: "daily_ayah",
        displayOrder: 9,
        screenLocation: "temukan_main"
    },
];

const seedContent = async () => {
    const client = await pool.connect();
    try {
        console.log('Memulai proses seeding konten halaman Temukan...');
        await client.query('BEGIN');

        await client.query('TRUNCATE TABLE featured_content RESTART IDENTITY;');
        console.log('Tabel featured_content berhasil dikosongkan.');

        for (const item of featuredContent) {
            const query = `
                INSERT INTO featured_content (title, subtitle, image_url, action_type, action_value, display_order, screen_location)
                VALUES ($1, $2, $3, $4, $5, $6, $7);
            `;
            await client.query(query, [item.title, item.subtitle, item.imageUrl, item.actionType, item.actionValue, item.displayOrder, item.screenLocation]);
        }

        await client.query('COMMIT');
        console.log(`\n🎉 Berhasil menanamkan ${featuredContent.length} item konten.`);
    } catch (error) {
        await client.query('ROLLBACK');
        console.error('❌ ERROR saat proses seeding:', error);
    } finally {
        client.release();
        await pool.end();
    }
};

seedContent();
