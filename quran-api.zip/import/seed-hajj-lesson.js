// import/seed-hajj-lesson.js

const { Pool } = require('pg');
const path = require('path');
require('dotenv').config({ path: path.resolve(__dirname, '../.env') });

const pool = new Pool({
    user: process.env.DB_USER,
    host: process.env.DB_HOST,
    database: process.env.DB_DATABASE,
    password: process.env.DB_PASSWORD,
    port: process.env.DB_PORT,
});

const seedHajjLesson = async () => {
    const client = await pool.connect();
    try {
        console.log('Memulai proses seeding pelajaran detail Topik Haji...');
        await client.query('BEGIN');

        // 1. Cari ID dari materi induk "Hajj"
        const materialRes = await client.query("SELECT id FROM learning_materials WHERE action_value = 'hajj'");
        if (materialRes.rows.length === 0) {
            throw new Error("Materi 'Hajj' (action_value: 'hajj') tidak ditemukan. Jalankan seed-all-learning-content.js dulu.");
        }
        const materialId = materialRes.rows[0].id;
        console.log(`- Materi Induk "Hajj" ditemukan dengan ID: ${materialId}`);

        // 2. Definisikan semua pelajaran di dalam Topik Haji
        const hajjLessons = [
            { title: "Al-Baqara", subtitle: "Kemampuan beradaptasi dalam memenuhi kewajiban agama", contentValue: "hajj-baqarah-1", order: 1 },
            { title: "Al-Baqara", subtitle: "Pentingnya Safa dan Marwah", contentValue: "hajj-baqarah-2", order: 2 },
            { title: "Al-Maaida", subtitle: "Ketika berada dalam keadaan Ihram", contentValue: "hajj-maaida-1", order: 3 },
            { title: "Al-Hajj", subtitle: "Pengumuman untuk Melaksanakan Ibadah Haji", contentValue: "hajj-hajj-1", order: 4 },
            { title: "As-Saaffaat", subtitle: "Asal Mula Aksi Pengorbanan", contentValue: "hajj-saaffaat-1", order: 5 },
            { title: "Al-Kawthar", subtitle: "Kegiatan Berkurban", contentValue: "hajj-kawthar-1", order: 6 },
        ];

        const lessonIds = {}; // Untuk menyimpan ID pelajaran yang baru dibuat

        // 3. Masukkan semua pelajaran di atas ke tabel `lessons`
        for (const lesson of hajjLessons) {
            const res = await client.query(
                "INSERT INTO lessons (material_id, title, subtitle, content_type, content_value, display_order) VALUES ($1, $2, $3, 'lesson', $4, $5) RETURNING id",
                [materialId, lesson.title, lesson.subtitle, lesson.contentValue, lesson.order]
            );
            lessonIds[lesson.contentValue] = res.rows[0].id;
        }
        console.log(`- Berhasil menanamkan ${hajjLessons.length} pelajaran untuk Topik Haji.`);

        // 4. Definisikan semua "slide" untuk pelajaran pertama ("hajj-baqarah-1")
        const firstLessonId = lessonIds['hajj-baqarah-1'];
        const steps = [
            { order: 1, type: 'intro_text', content: { title: "Surat Al-Baqarah", text: "Surat Al-Baqarah adalah surat ke-2 dalam Al-Quran. Surat ini terdiri dari 286 ayat dan diturunkan di Madinah..." } },
            { order: 2, type: 'verse_display', content: { verse_key: "2:196", show_play_button: false, transliteration: "wa atimmul-ḥajja wal-'umrata lillāh..." } },
            { order: 3, type: 'translation_display', content: { verse_key: "2:196" } },
            { order: 4, type: 'information_text', content: { title: "Informasi", text: "Ayat ini berbicara tentang pentingnya fleksibilitas dan kemampuan beradaptasi dalam memenuhi kewajiban agama..." } },
            { order: 5, type: 'hadith_reference', content: { title: "Hadith", text: "Membuat segala sesuatunya menjadi mudah\n\nDari Anas -radhiyallāhu 'anhu-, ia berkata, \"Rasulullah -ṣallallāhu 'alaihi wa sallam- bersabda, 'Permudahlah dan jangan mempersulit, gembirakanlah orang-orang dengan menyampaikan kabar gembira kepada mereka dan janganlah kamu membuat mereka kecewa'.\n\nHadis diriwayatkan oleh Imam Bukhari & Muslim." } },
            { order: 6, type: 'knowledge_review_boolean', content: { title: "Knowledge Review", question: "Menunaikan ibadah haji adalah wajib hukumnya, bahkan bagi mereka yang mungkin tidak memiliki kemampuan untuk menunaikannya.", correct_answer: false } },
            { order: 7, type: 'knowledge_review_mcq', content: { title: "Knowledge Review", question: "Bentuk ibadah alternatif bagi mereka yang tidak dapat memberikan persembahan hewan adalah", options: ["Menunaikan ibadah haji", "Puasa 3 hari selama ziarah", "Puasa 3 hari selama ziarah"], correct_index: 1 } }
        ];

        // 5. Masukkan semua "slide" ke database
        for (const step of steps) {
            await client.query(
                'INSERT INTO lesson_steps (lesson_id, step_order, step_type, content) VALUES ($1, $2, $3, $4)',
                [firstLessonId, step.order, step.type, JSON.stringify(step.content)]
            );
        }
        console.log(`- Berhasil menanamkan ${steps.length} slide untuk pelajaran pertama Topik Haji.`);

        await client.query('COMMIT');
        console.log('\n✅ Proses seeding semua konten pelajaran Haji selesai dengan sukses!');
    } catch (error) {
        await client.query('ROLLBACK');
        console.error('❌ ERROR saat proses seeding:', error);
    } finally {
        client.release();
        await pool.end();
    }
};

seedHajjLesson();
